<?php

// Insert All PHP codes for Home Page Under this comment
include("check_connection.php");
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $cardID = $_POST["cardID"]; // Fix variable name
    $bookTitle = $_POST["bookTitle"]; // Fix variable name
    $bookAuthor = $_POST["bookAuthor"]; // Fix variable name
    $yearPublished = $_POST["yearPublished"]; // Fix variable name
    $publisher = $_POST["publisher"]; // Fix variable name
    
    // Insert book into database
    // Your database insertion code here
    $query = "INSERT INTO books (card_id, book_title, book_author, year_published, publisher) VALUES ('$cardID', '$bookTitle', '$bookAuthor', '$yearPublished', '$publisher')";
    $result = mysqli_query($conn, $query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PS Library Management System</title>
    <link rel="shortcut icon" href="./favicon.png" type="image/x-icon">
    <script src="https://kit.fontawesome.com/5253132cc4.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="./script.js"></script>
    <script>  
$(document).ready(function() { // Fix document.ready function
  $("#addBookForm").on("submit", function(event) { // Fix submit event function
    event.preventDefault(); // Prevent form submission

    // Extract form data
    var cardID = $("#cardID").val();
    var bookTitle = $("#bookTitle").val();
    var bookAuthor = $("#bookAuthor").val();
    var yearPublished = $("#yearPublished").val();
    var publisher = $("#publisher").val();

    // Call the function to add book to library
    addBookToLibrary(cardID, bookTitle, bookAuthor, yearPublished, publisher);
});

  function addBookToLibrary(cardID, bookTitle, bookAuthor, yearPublished, publisher) {
    // Send an AJAX request to the server
    $.post("add_book.php", { cardID: cardID, bookTitle: bookTitle, bookAuthor: bookAuthor, yearPublished: yearPublished, publisher: publisher }, function(response) {
      // Handle the response from the server
      if (response.success) {
        // Optionally, you can display a success message or update the UI
        console.log("Book added successfully");
      } else {
        // Optionally, you can display an error message or handle the error
        console.error("Failed to add book");
      }
    });
  }
});

</script>
</head>
<body>
    <!-- Do Not Touch Header, Formality Purposes -->
    <header>
        <div class="title_bar">
            <img src="./favicon.png" alt="" id="website_logo">
            <br>
            <h1 id="website_name">PS Library Management System - &nbsp; <i class="fa-solid fa-folder-plus"></i> Create Book Page</h1>
        </div>
        <nav>
            <ul>
                <a href="./home-page.php"><li><i class="fa-solid fa-house"></i>HOME PAGE</li></a>
                <a href="./create-book.php"><li id="active_tab"><i class="fa-solid fa-folder-plus"></i>CREATE BOOK</li></a>
                <a href="./search-book.php"><li><i class="fa-solid fa-magnifying-glass"></i>SEARCH BOOK</li></a>
                <a href="./update-book.php"><li><i class="fa-solid fa-pen-to-square"></i>UPDATE BOOK</li></a>
                <a href="./delete-book.php"><li><i class="fa-sharp fa-solid fa-trash"></i>DELETE BOOK</li></a>
            </ul>
        </nav>
    </header>
    <!-- Do Not Touch Header, Formality Purposes -->
    
    <!-- Insert All HTML codes for Create Book Page Under this comment -->
    <div id="content">
        <h2>Create Book</h2>
        <form id="addBookForm">
  <input type="text" id="cardID" placeholder="Card ID">
  <input type="text" id="bookTitle" placeholder="Book Title">
  <input type="text" id="bookAuthor" placeholder="Book Author">
  <input type="text" id="yearPublished" placeholder="Year Published">
  <input type="text" id="publisher" placeholder="Publisher">
  <input type="submit" value="Add Book">
</form>
</div>
 
</body>
</html>