$(document).ready(function() { // Fix document.ready function
  $("#addBookForm").on("submit", function(event) { // Fix submit event function
    event.preventDefault(); // Prevent form submission

    // Extract form data
    var cardID = $("#cardID").val();
    var bookTitle = $("#bookTitle").val();
    var bookAuthor = $("#bookAuthor").val();
    var yearPublished = $("#yearPublished").val();
    var publisher = $("#publisher").val();

    // Call the function to add book to library
    addBookToLibrary(cardID, bookTitle, bookAuthor,yearPublished ,publisher);
});

  // The function to add book to library
  function addBookToLibrary(cardID, bookTitle, bookAuthor,yearPublished ,publisher) {
    $.ajax({
        type: "POST",
        url: "add_book.php",
        // data object is key: value
        data: { cardIDKey: cardID,
                bookTitleKey: bookTitle,
                bookAuthorKey: bookAuthor,
                yearPublishedKey: yearPublished,
                publisherKey: publisher
        },
        cache: false,
        success: function(data) {
            alert(data);
        },
        error: function(xhr, status, error) {
            console.error(xhr);
        }
    });
  }
});