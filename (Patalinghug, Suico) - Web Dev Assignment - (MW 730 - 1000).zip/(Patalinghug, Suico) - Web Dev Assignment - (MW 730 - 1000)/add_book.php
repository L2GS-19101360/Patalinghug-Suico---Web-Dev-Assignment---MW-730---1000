<?php
    // include database connection
    include("check_connection.php");
 
    // get the values from the post data body using the Key
    $cardID = $_POST['cardIDKey'];
    $bookTitle = $_POST['bookTitleKey'];
    $bookAuthor = $_POST['bookAuthorKey'];
    $yearPublished = $_POST['yearPublishedKey'];
    $publisher = $_POST['publisherKey'];
    // mysql query accepts connection, and a query string
    $result=mysqli_query($est_conn, "INSERT INTO books(BOOK_ID, BOOK_TITLE, BOOK_AUTHOR, YEAR_PUBLISH, PUBLISHER) VALUES('" . $cardID . "', '" . $bookTitle . "', '" . $bookAuthor . "', '" . $yearPublished . "', '" . $publisher . "')");
    if($result != null) {
     echo 'Book added succesfully!';
    } else {
       echo "Error: " . $sql . "" . mysqli_error($est_conn);
    }

    // close the database connection
    mysqli_close($est_conn);

?>